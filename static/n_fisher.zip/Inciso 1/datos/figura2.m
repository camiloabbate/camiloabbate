clear all;
clc;
data=xlsread('data','dataforexport','B3:C252');
inf=data(:,1);
tasai=data(:,2);

%defino el tiempo



tiempo=0:249;
t=tiempo/4;
time=1954.75 + t;

figure(1);
hold on;
plot(time,inf,'-b','LineWidth',2);
plot(time,tasai,'--r','LineWidth',2);
xlim([1954.75 2017]);
ylim([-5 20]);
title('Estados Unidos');
xlabel('A�o');
ylabel('Porcentaje por a�o');
legend('inflaci�n','tasa de inter�s nominal')

saveas(gca, 'Figura2.eps','epsc');