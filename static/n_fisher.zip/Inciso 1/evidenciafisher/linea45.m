clear all; clc;

data=xlsread('linea45.xlsx','infla-tasai','B5:C35')

inf=data(:,1);
tasai=data(:,2);

clear data;

figure(1);
scatter(inf,tasai,'MarkerFaceColor',[0 0 1]);
refline(1,0);
title('31 pa�ses');
xlabel('Tasa de inflaci�n, porcentaje por a�o');
ylabel('Tasa de inter�s nominal, porcentaje por a�o');

saveas(gca, 'Figura1.eps','epsc');

