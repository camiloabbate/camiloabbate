%CORRER �STA RUTINA, LLAMAR� A TODAS LAS DEM�S RUTINAS NECESARIAS PARA
%RESOLVER EL INCISO 3, 4 y 5:

tic;
clc;
clear; 
close all;


% Me traigo los observables
Y= xlsread('data.xlsx','data_ready','G3:I251');

deltayt= Y(:,1);
rt= Y(:,2);
deltait=Y(:,3);

data=[deltayt rt deltait];
clear Y;

medias=mean(data);
BAR=var(data); %varianza de los observables

% BAR(1)/20  %prior (media) de la varianza de deltayt
% BAR(2)/20  %prior (media) de la varianza de rt
% BAR(3)/20  %prior (media) de la varianza de deltait

%�stas medias y varianzas las utilic� como par�metros iniciales en una primera
%optimizaci�n. Los par�metros obtenidos de esa primera optimizaci�n los uso
%como nuevos par�metros iniciales en �ste codigo

%Par�metros iniciales:

%�stos son viejos, los dej� por si acaso:  
 %{
param_in = [ 0.4143;...
1.6490;...
-0.0023;...
0.802770650009451;...
-0.361326622272722;...
0.865227934456986;...
-0.188360232684491;...
-0.199692158185477;...
-0.359887097983186;...
0.212247065935633;...
-0.124030224281307;...
0.361936481583938;...
-0.0422622979476190;...
0.142075845107398;...
0.0411389998408341;...
3.39232108891089;...
2.23036380129763;...
-0.753765459373223;...
-0.820729828142808;...
1.55276122971542;...
-1.08773589729568;...
0.287513823398107;...
4.10221021961113;...
2.73218566506941;...
-0.572537587182766;...
-0.491197864968637;...
0.334986067158999;...
0.646933258100874;...
-0.492915829296669;...
0.0737985667761840;...
0.970282355920652;...
0.146471002963192;...
0.147006732193721;...
1.02531299350931;...
0.215231118139941;...
-13.6908872940807;...
-21.8252737901133;...
-13.0945008857120;...
];          
    %}
 
%Ahora s�, par�metros iniciales: Los saqu� de una optimizaci�n previa:
 param_in=xlsread('paraminicialesylike.xlsx','Hoja1','D3:D40');
 
%Primer optimizador: simulated annealing:
[ loglik_out, param_out, ~ ] = annealing_fisher( param_in, data );


param_in = param_out;
%Segundo optimizador: Fminsearch:
[ loglik_out, param_out, ~ ] = fmin_fisher( param_in, data );

param_in = param_out; 
%Tercer optimizador: Newton-Raphson
[ loglik_out, param_out, unobserved ] = newton_fisher( param_in, data );


var1=exp(param_out(36)); 
var2=exp(param_out(37));
var3=exp(param_out(38)); 

periodos_irf=100;

vars=16;

nlags=4;

shocks=4;

param=param_out;

 media1  = param(1);
        media2 = param(2);
        media3  = param(3);
        b1  = param(4);
        b2 = param(5);
        b3  = param(6);
        b4 = param(7);
        b5  = param(8);
        b6 = param(9);
        b7  = param(10);
        b8 = param(11);
        b9  = param(12);
        b10 = param(13);
        b11  = param(14);
        b12 = param(15);
        c11  = param(16);
        c12 = param(17);
        c13 = param(18);
        c14 = param(19) ;
        c21 = param(20);
        c22 = param(21);
        c23 = param(22);
        c24 = param(23);
        c31 = param(24);
        c32 = param(25);
        c33 = param(26);
        c34 = param(27);
        r1 = param(28);
        r2 = param(29);
        r3 = param(30);
        r4 = param(31);
        phi1= param(32);
        phi2 = param(33);
        phi3 = param(34);
        phi4 = param(35);
        RR1 = param(36);
        RR2 = param(37);
        RR3 = param(38);
        
       RR1_b = exp(RR1);
       RR2_b = exp(RR2);
       RR3_b = exp(RR3);
       
       
%Matriz F:
B1=[b1 0 0; 0 b2 0; 0 0 b3];

B2=[b4 0 0; 0 b5 0; 0 0 b6];

B3=[b7 0 0; 0 b8 0; 0 0 b9];

B4 = [b10 0 0; 0 b11 0; 0 0 b12];

Ce= [c11 c12 c13 c14;c21 c22 c23 c24; c31 c32 c33 c34];

rho=[r1 0 0 0; 0 r2 0 0 ; 0 0 r3 0; 0 0 0 r4];


Ident=eye(9);
Cero1=zeros(9,3);
Cero2=zeros(9,4);
Cero3=zeros(4,12);

F=[B1 B2 B3 B4 Ce*rho;[Ident Cero1] Cero2; Cero3 rho];

%Para armar P solo me falta psi:
psi = [phi1 0 0 0; 0 phi2 0 0 ; 0 0 phi3 0 ; 0 0 0 phi4];


P=[Ce*psi;Cero2;psi];


% Initialize arrays to compute impulse responses
irf = zeros(periodos_irf,vars,shocks);  % First dimension:  periods
                                    % Second dimension: variables
                                    % Third dimension: shocks

Fpow=eye(16);   % Initialize matrix Bc^(t-1);

for t=1:periodos_irf
    % Compute all impulse responses at t at once and store result in Yimpt 
    % Yimpt(1:nvar,i) contains irf at t to shock i
    Yimpt = Fpow*P;
    
    % Update Bpowtm1 matrix for next iteration
    Fpow = Fpow*F;
    
    % Store impulse responses at t where they belong
    for ishock=1:shocks     % Iterate over shocks
        irf(t,:,ishock) = Yimpt(1:vars,ishock)';
    end
end



%Hasta ah� me consegu� efectos sobre los No-Observables, por lo que
%necesito multiplicar por la matriz H' para tener el efecto sobre 
%el vector ot
%Llamo HH a la matriz H' de Uribe:

HH=[1 0 0 -1 0 0 0 0 0 0 0 0 0 0 1 0 ; 0 -1 1 0 0 0 0 0 0 0 0 0 0 0 0 0;0 0 1 0 0 -1 0 0 0 0 0 0 1 0 0 0];

%Aclaraci�n: Las siguientes matrices "Primer,.....,Cuart" son matrices de 
% 3x100, que almacenan las respuestas de los observables frente a:
%Primer shock: permanente, monetario  (xm)
%Segundo shock: no-permanente, monetario  (zm)
%Tercer shock: permanente, no monetario   (xn)
%Cuarto shock: no permanente, no monetario   (zn)

Primer=HH*irf(:,:,1)';
Segun=HH*irf(:,:,2)';
Tercer=HH*irf(:,:,3)';
Cuart=HH*irf(:,:,4)';

%Hasta ac� tengo las impulse response sobre:
% [ variaci�n output 
%   tasa de inter�s real
%   variaci�n tasa de i nominal ]


%Entonces para hallar los impulse response sobre los niveles del output
%y los niveles de la tasa de i nominal tengo que sumar los irfs


%ahora efecto sobre nivel de it
%esto nos va a servir para despu�s hallar efecto sobre pit
% pit = it - rt

for i=1:periodos_irf;
    B=Primer(3,1:i);
    inominal_shock1(i)=sum(B);  %efecto sobre i nominal shock xm
end

ireal_shock1=Primer(2,:);



%Shock xm, monetario permanente sobre nivel de output
for i=1:periodos_irf;
    Z=Primer(1,1:i);
    output_shock1(i)=sum(Z);
end


%Ahora, shocks transitorios

ireal_shock2=Segun(2,:);


%computo efecto de shock transitorio monetario sobre nivel de output
for i=1:periodos_irf;
    K=Segun(1,1:i);
    output_shock2(i)=sum(K);
end

%computo efecto de shock transitorio monetario sobre nivel de tasa de i
%nominal
for i=1:periodos_irf;
    L=Segun(3,1:i);
    inominal_shock2(i)=sum(L);
end


%�sto ya no me sirve
%{ 
figure(2);
subplot(2,2,1)
plot(1:periodos_irf,output_shock2);
title('Respuesta de output frente a shock monetario transitorio');



%}

%y por ultimo shock transitorio no-monetario 
%solo le pega al output


for i=1:periodos_irf;
    U=Cuart(1,1:i);
    output_shock4(i)=sum(U);
end

%{ 
figure(2);
plot(1:periodos_irf,output_shock4);
title({'Shock Transitorio sobre la TFP','Respuesta del Output',});
%}

figure(1);
subplot(2,2,1);
hold on;
plot(1:periodos_irf,inominal_shock1,'--r','LineWidth',2);
plot(1:periodos_irf,inominal_shock1-ireal_shock1,'-b','LineWidth',2);
title({'Shock Permanente:Tasa Nominal de Inter�s','Respuesta de:', 'Tasa Nominal de Inter�s e Inflaci�n'});
legend('tasa de inter�s nominal','inflaci�n','Location','southeast');

subplot(2,2,2);
hold on;
plot(1:periodos_irf,inominal_shock2,'--r','LineWidth',2);
plot(1:periodos_irf,inominal_shock2-ireal_shock2,'-b','LineWidth',2);
title({'Shock Transitorio:Tasa Nominal de Inter�s','Respuesta de:', 'Tasa Nominal de Inter�s e Inflaci�n'});
legend('tasa de inter�s nominal','inflaci�n','Location','southeast');

subplot(2,2,3);
hold on;
plot(1:periodos_irf,output_shock1,'-b','LineWidth',2);
title({'Shock Permanente:Tasa Nominal de Inter�s','Respuesta del Output'});
legend('Output','Location','northeast');

subplot(2,2,4);
hold on;
plot(1:periodos_irf,output_shock2,'-b','LineWidth',2);
title({'Shock Transitorio:Tasa Nominal de Inter�s','Respuesta del Output'});
legend('Output','Location','northeast');


figure(2);
plot(1:periodos_irf,ireal_shock2,'-g','LineWidth',2);
title({'Shock Transitorio:Tasa Nominal de Inter�s','Respuesta de la Tasa de Inter�s Real'});
legend('Tasa de I. Real','Location','northeast');
%%%%

%AC� ARRANCA EL INCISO 5

%%%%




unob=unobserved(:,2:250);

for i=2:size(unob,2);
 
    unobt=unob(:,i);   %Unobservable(t)
    fporunobtmenos1 = F*(unob(:,i-1)); %F*Unobservable(t-1)
    wgorro(:,i-1)= unobt - fporunobtmenos1; %ser�an los errores w_gorro = %Unobservable(t) - F*Unobservable(t-1)
end

%me queda una matriz de 16x248, porque no utiliz� la primera obs de los no
%observables: vector de ceros

M = 5000; %Prob� inicialmente con M=186, luego 2000 y finalmente me decid� por 5000

    nwgorro=[wgorro(1:3,:);wgorro(13:16,:)]; %Solo los errores que me interesan
    %capaz llamar nwgorro mejor

    %Ahora me construyo la matriz "nwgorro en tres dimensiones" (nwgtercer)
    %me va a servir para sacar las M muestras
for j=1:size(nwgorro,2);
     Mat(:,j,j)=nwgorro(:,j); 
     nwgtercer(:,:,j) = Mat(:,j,j);
    
end
clear Mat;

%Ahora armo las muestras, extraidas con reposici�n de una uniforme discreta
%con soporte 1 a M=2000
%cada vector llamado "muestra" con minuscula es un vector de 1x248
%donde el 248 indica que puede salir cualquier numero entre 1 y 248
%dicho n�mero va a indexar el nwgtercer (,,dicho n�mero)
%para que podamos ubicar el nwgtercer
%Muestra con mayuscula es una feroz matriz de 248x186
%248 filas para indicar cada numerito asociado a nwgtercer
%186 porque queremos M=186 muestras

for m=1:M;
muestra=random('unid',248,1,248);
Muestra(:,m)=muestra';
end

%Ahora entonces es entonces crear las w* (186 de ellas hay)

%Hay que relacionar Muestra (248 x 186) con nwgtercer (7x1x248)

%Como cada columna de Muestra tiene 248 n�meros, cada uno de 
%�stos n�meros se corresponde con un vector de nwgtercer:
%Ejemplo: Primera columna de muestra arranca con el valor 33
%Esto es: nwgtercer(:,:,33) llenar� la primera fila de w*1

for z=1:M;
    usar=Muestra(:,z);
    for j=1:248;
        westrpre(:,j) = nwgtercer(:,:,usar(j,:)); %w_estrella_previa
    end
    westr(:,:,z)= westrpre; %w_estrella
end

%Ahora viene b) Construir data artificial
%La voy a construir acorde a las leyes de movimiento:

%{
VAR(4):

    Ygorro(t) = B1*Ygorro(t-1) + ..... + B4*Ygorro(t-4) + C*u(t)

VAR(1):

    u(t+1) = rho*u(t) + phi*eps(t+1)
  
%}


%entonces valiendome de las leyes de movimiento lo que voy a hacer,
%para construir recursivamente la data artificial:

%{

Armamos u(t) y el resultado metemos en el VAR(4)
VAR(1):

    u(t+1) = rho*u(t) + phi*eps(t+1) = rho * u(t) + w_estrella_l

donde w_estrella_l son las 4 �ltimas filas de w_estrella

con lo de arriba, nos armamos entonces "u(t)_estrella"

y esa u(t)_estrella metemos en:

  VAR(4):

    Ygorro(t) = B1*Ygorro(t-1) + ..... + B4*Ygorro(t-4)
                + Ce*rho*u(t-1)_estrella + w_estrella_f

donde w_estrella_f son las primeras 3 filas de w_estrella

  
%}

%hacemos �sto para los M=2000 casos, luego estimamos las matrices
%y luego generamos las IRF's
%intentar� hacer todo en un gran c�digo: 
%capaz es m�s facil hacerlo por partes

%Lo primero:
%Separar w_estrella_f y w_estrella_l
%los llamo wf y wl respectivamente:

wf=westr(1:3,:,:);
wl=westr(4:7,:,:);

for ii=1:M;
    el=wl(:,:,ii); %"error l " , entra como error del VAR (1)
    for jj=1:248;
        if jj<2;
    uart(:,jj)=el(:,jj);
        else
    uart(:,jj)=rho*UA(:,jj-1)+el(:,jj);
        end
        UA(:,jj)=uart(:,jj);
    end
    UART(:,:,ii)=UA;
end

%UART es una matriz de 3 dimensiones: en la tercera dimension
%hay M entradas. Es decir tenemos M=2000 matrices de 4x247
%Ponele agarramos la primera entrada de la tercera dimension:
%lo que tenemos ah� es 247 observaciones del vector u(t) para t=1:247

%Ahora falta generar las Ygorroestrellas
% utilizamos las UART ac�!
% y las wf

for gg=1:M;
    ef=wf(:,:,gg); %"error f", entra como error del VAR (4);
    for qq=1:248;
        if qq<2;
            yart(:,qq)=ef(:,qq);
        elseif qq<3;
                yart(:,qq) =  B1*YA(:,qq-1)+ Ce*rho*UART(:,qq-1,gg)  + ef(:,qq);
        elseif qq < 4;
                    yart(:,qq) = B2*YA(:,qq-2) + B1*YA(:,qq-1) + Ce*rho*UART(:,qq-1,gg) + ef(:,qq);
        elseif qq<5;
                        yart(:,qq) = B3*YA(:,qq-3) + B2*YA(:,qq-2) + B1*YA(:,qq-1) + Ce*rho*UART(:,qq-1,gg) + ef(:,qq);
                    else
                        yart(:,qq) = B4*YA(:,qq-4) + B3*YA(:,qq-3) + B2*YA(:,qq-2) + B1*YA(:,qq-1) + Ce*rho*UART(:,qq-1,gg) + ef(:,qq);
                    end
     YA(:,qq)=yart(:,qq);
    end
    YART(:,:,gg)=YA;
end
    
%Solo falta la parte c), estimar una cantidad de veces a los
%B_estrella_i'es y a los rho_estrella_i'es, pues Ce y Phi los impongo
%Notar que llamaremos al programa var_ls en total 5000 por 2 veces  = 10000 veces

for pp=1:M;
    outputVARU(:,:,pp)=var_ls(UART(:,:,pp),1);  %VAR con las U, 1 solo rezago ac�
    outputVARY(:,:,pp)=var_ls(YART(:,:,pp),4);
   
end

%ah� me acabo de construir M vars para ut y para yt (estrellas ambas)
%y ahora loopeo para ir armando las IRF'S

% Initialize arrays to compute impulse responses
irfboot = zeros(periodos_irf,vars,shocks,M);  % First dimension:  periods
                                    % Second dimension: variables
                                    % Third dimension: shocks
                                    % Cuarta dimension: num de muestra

for tt=1:M;
    %definimos la F a usar y la rho a usar
    %antiguamente la F era: 
    %F=[B1 B2 B3 B4 Ce*rho;[Ident Cero1] Cero2; Cero3 rho]
    Fnueva=[outputVARY(:,:,tt).coef{1} outputVARY(:,:,tt).coef{2} outputVARY(:,:,tt).coef{3} outputVARY(:,:,tt).coef{4} Ce*(outputVARU(:,:,tt).coef{1});[Ident Cero1] Cero2; Cero3 outputVARU(:,:,tt).coef{1} ];
   %Inicializar la matriz ffpow
   ffpow=eye(16);
    for fff=1:periodos_irf;
        % Compute all impulse responses at t at once and store result in Yimpt 
    % mmpt(1:nvar,i) contains irf at t to shock i
    
        mmpt=ffpow*P;
        
       
    % Update Bpowtm1 matrix for next iteration
    ffpow = ffpow*Fnueva;
    
    % Store impulse responses at t where they belong
    for ishockboot=1:shocks     % Iterate over shocks
        irfboot(fff,:,ishockboot,tt) = mmpt(1:vars,ishockboot)';
    end
    end
end

%Genial, ya existe irfboot que es una matriz de 4 dimensiones:
%tiene los impulse response para la state equation:
%esta organizada: 100 periodos por 16 variables (matrices de 100x16)
%por cada shock estan en un compartimiento (4 shocks)
%por cada muestra M est�n en otro compartimiento (M muestras)
%es decir: (4*M matrices de 100x16 sino me equivoco)

%Procedo a armar la respuesta de los observables:


%Antigua Htraspuesta:
%HH=[1 0 0 -1 0 0 0 0 0 0 0 0 0 0 1 0 ; 0 -1 1 0 0 0 0 0 0 0 0 0 0 0 0 0;0 0 1 0 0 -1 0 0 0 0 0 0 1 0 0 0];
%La actual es la misma!

%vamos a tener M respuestas diferentes por variable por shock!
%15/12/2017

for dd=1:M;
    
Primerboot(:,:,1,dd)=HH*irfboot(:,:,1,dd)'; %esto ser�a impulse response de observables(t), primer shock, todas las muestras 
Segunboot(:,:,2,dd)=HH*irfboot(:,:,2,dd)';
Tercerboot(:,:,3,dd)=HH*irfboot(:,:,3,dd)';
Cuartboot(:,:,4,dd)=HH*irfboot(:,:,4,dd)';

end


pctg=95; %para el intervalo de confianza del 95%

% Compute error bands
pctg_inf = (100-pctg)/2; 
pctg_sup = 100 - (100-pctg)/2;

%Voy computando las bandas, y luego creo los dos gr�ficos que quiero:

%No necesito las bandas para rt, pero s� la respuesta
% de rt ante los dos shocks monetarios (tasa de i nominal) 
%porque luego van a servir para las
%bandas para pi_t (inflaci�n)

%Rt, ante shock xm
resprtboot_xm=Primerboot(2,:,1,:);  %respuesta rt boot a xm
%fin rt, ante shock xm

%Rt, ante shock zm
resprtboot_zm=Segunboot(2,:,2,:);  %respuesta rt boot a zm
%fin rt, ante shock zm


%�sta parte la dejo s�lo por si la necesite:
%{
figure(20);
for rr=1:M;
    hold on;
plot(resprtboot_xm(:,:,1,rr));
end

%dejando solamente el percentil 90 y 10:

inferior_rt_s1=prctile(resprtboot_xm,pctg_inf,4);
superior_rt_s1=prctile(resprtboot_xm,pctg_sup,4);


 
figure(21);
hold on;
plot(ireal_shock1);
plot(inferior_rt_s1,'--k');
plot(superior_rt_s1,'--k','Linewidth',1.5);
grid on;
title('Respuesta de la tasa de inter�s real a shock monetario permanente','Fontsize',12);



%bandas rt, shock zm

resprtboot_zm=Segunboot(2,:,2,:);  %respuesta rt boot a zm

figure(20);
for rr=1:M;
    hold on;
plot(resprtboot_xm(:,:,1,rr));
end

%dejando solamente el percentil 90 y 10:

inferior_rt_s1=prctile(resprtboot_xm,pctg_inf,4);
superior_rt_s1=prctile(resprtboot_xm,pctg_sup,4);


%fin bandas rt, shock zm

%}

%recordar que tenemos los efectos sobre las dif, y queremos sobre los
%niveles!!

%Camilo Abbate: 23/12/2017 09:44 pm

%Camilo Abbate: 26/12/2017

%Me consigo respuesta it, frente a los dos shocks monetarios:

%it, ante shock xm:
respdeltaitboot_xm=Primerboot(3,:,1,:);  %respuesta delta it boot a xm

%Ahora respuesta del nivel it:

for j=1:M;
    for    i=1:periodos_irf;
    za=respdeltaitboot_xm(1,1:i,1,j);
    it_boot_shock1(i)=sum(za);
    end
it_boot_shock1_final(:,:,:,j)=it_boot_shock1;
end

it_boot_shock1_final=permute(it_boot_shock1_final,[2,1,3,4]);

%Por lo que la rpta de infla_t ser�a: rpta de it menos rpta rt

for r=1:M;
    resp_pit_boot_xm(:,:,1,r)=it_boot_shock1_final(:,:,1,r)-resprtboot_xm(:,:,1,r);
end


%todas las rptas de la inflaci�n, de las 2000 simulaciones
%{

for oj=1:M;
    hold on;
plot(resp_pit_boot_xm(:,:,1,oj));
end
%}

%bandas
inferior_pit_s1=prctile(resp_pit_boot_xm,pctg_inf,4);
superior_pit_s1=prctile(resp_pit_boot_xm,pctg_sup,4);

%fin it, y luego pit ante shock xm

%it, ante shock zm:
respdeltaitboot_zm=Segunboot(3,:,2,:);  %respuesta delta it boot a zm

%Ahora respuesta del nivel it:

for h=1:M;
    for    gi=1:periodos_irf;
    zu=respdeltaitboot_zm(1,1:gi,1,h);
    it_boot_shock2(gi)=sum(zu);
    end
it_boot_shock2_final(:,:,:,h)=it_boot_shock2;
end

it_boot_shock2_final=permute(it_boot_shock2_final,[2,1,3,4]);

%Por lo que la rpta de infla_t ser�a: rpta de it menos rpta rt

for w=1:M;
    resp_pit_boot_zm(:,:,1,w)=it_boot_shock2_final(:,:,1,w)-resprtboot_zm(:,:,1,w);
end

inferior_pit_s2=prctile(resp_pit_boot_zm,pctg_inf,4);
superior_pit_s2=prctile(resp_pit_boot_zm,pctg_sup,4);

%fin rpta it y luego pit, listo para graficar

%Ahora vemos la respuesta del NIVEL del output_boot frente a xm

respdeltaytboot_xm=Primerboot(1,:,1,:);  %respuesta deltayt boot a xm

for j=1:M;
    for    i=1:periodos_irf;
    zzz=respdeltaytboot_xm(1,1:i,1,j);
    output_boot_shock1(i)=sum(zzz);
    end
output_boot_shock1_final(:,:,:,j)=output_boot_shock1;
end



inferior_yt_s1=prctile(output_boot_shock1_final,pctg_inf,4);
superior_yt_s1=prctile(output_boot_shock1_final,pctg_sup,4);

%%Fin respuesta del NIVEL del output_boot frente a xm

%Ahora vemos la respuesta del NIVEL del output_boot frente a zm

respdeltaytboot_zm=Segunboot(1,:,2,:);


for u=1:M;
    for    hi=1:periodos_irf;
    gf=respdeltaytboot_zm(1,1:hi,1,u);
    output_boot_shock2(hi)=sum(gf);
    end
output_boot_shock2_final(:,:,1,u)=output_boot_shock2;
end

%todas las bandas para output:
figure(3);
subplot(1,2,1);
for l=1:M;
    hold on;
plot(output_boot_shock1_final(:,:,1,l));
end
title({'Naive Bootstrap: Shock permanente', 'a la tasa de inter�s nominal', 'Respuesta del Output'});

subplot(1,2,2);
for a=1:M;
    hold on;
plot(output_boot_shock2_final(:,:,1,a));
end
title({'Naive Bootstrap: Shock transitorio', 'a la tasa de inter�s nominal','Respuesta del Output'});
saveas(gca, 'outputboot.eps','epsc');

%todas las bandas para infla
figure(4);
subplot(1,2,1);
for i=1:M;
    hold on;
plot(resp_pit_boot_xm(:,:,1,i));
end
title({'Naive Bootstrap: Shock permanente', 'a la tasa de inter�s nominal', 'Respuesta de la tasa de Inflaci�n'});

subplot(1,2,2);
for l=1:M;
    hold on;
plot(resp_pit_boot_zm(:,:,1,l));
end
title({'Naive Bootstrap: Shock transitorio', 'a la tasa de inter�s nominal', 'Respuesta de la tasa de Inflaci�n'});
saveas(gca, 'inflaboot.eps','epsc');


pctg_inf = (100-pctg)/2;
pctg_sup = 100 - (100-pctg)/2;

inferior_yt_s2=prctile(output_boot_shock2_final,pctg_inf,4);
superior_yt_s2=prctile(output_boot_shock2_final,pctg_sup,4);



%%Fin respuesta del NIVEL del output_boot frente a zm


%finalmente las dos �ltimas im�genes:

figure(5);
subplot(2,2,1);
hold on;
plot(1:periodos_irf,inominal_shock1,'--r','LineWidth',2);
plot(1:periodos_irf,inominal_shock1-ireal_shock1,'-b','LineWidth',2);
plot(1:periodos_irf,inferior_pit_s1,'--k');
plot(1:periodos_irf,superior_pit_s1,'--k');
title({'Shock Permanente:Tasa Nominal de Inter�s','Respuesta de:', 'Tasa Nominal de Inter�s e Inflaci�n'});
legend('tasa de inter�s nominal','inflaci�n','Banda 95% Inf','Location','northeast');

subplot(2,2,2);
hold on;
plot(1:periodos_irf,inominal_shock2,'--r','LineWidth',2);
plot(1:periodos_irf,inominal_shock2-ireal_shock2,'-b','LineWidth',2);
plot(1:periodos_irf,inferior_pit_s2,'--k');
plot(1:periodos_irf,superior_pit_s2,'--k');
title({'Shock Transitorio:Tasa Nominal de Inter�s','Respuesta de:', 'Tasa Nominal de Inter�s e Inflaci�n'});
legend('tasa de inter�s nominal','inflaci�n','Banda 95% Inf','Location','southeast');

subplot(2,2,3);
hold on;
plot(1:periodos_irf,output_shock1,'-b','LineWidth',2);
plot(1:periodos_irf,inferior_yt_s1,'--k');
plot(1:periodos_irf,superior_yt_s1,'--k','Linewidth',1.5);
title({'Shock Permanente:Tasa Nominal de Inter�s','Respuesta del Ouput'});
legend('Output','Banda 95%','Location','northeast');

subplot(2,2,4);
hold on;
plot(1:periodos_irf,output_shock2,'-b','LineWidth',2);
plot(1:periodos_irf,inferior_yt_s2,'--k');
plot(1:periodos_irf,superior_yt_s2,'--k','Linewidth',1.5);
title({'Shock Transitorio:Tasa Nominal de Inter�s','Respuesta del Output'});
legend('Output','Banda 95%','Location','southeast');

saveas(gca, 'figura345uno.eps','epsc');


figure(6);
hold on;
plot(1:periodos_irf,ireal_shock1,'-b','LineWidth',2);
plot(1:periodos_irf,ireal_shock2,'--b','LineWidth',2);
title({'Shock Permanente y Transitorio:Tasa Nominal de Inter�s','Respuesta de la tasa de inter�s real'});
legend('Permanente','Transitorio','Location','northeast');

saveas(gca, 'figura345dos.eps','epsc');

unaultima=inominal_shock1-ireal_shock1;

figure(7);
hold on;
plot(1:20,inominal_shock1(:,1:20),'--r','LineWidth',2);
plot(1:20,unaultima(:,1:20),'-b','LineWidth',2);
plot(1:20,inferior_pit_s1(:,1:20),'--k');
plot(1:20,superior_pit_s1(:,1:20),'--k');
title({'Shock Permanente:Tasa Nominal de Inter�s','Respuesta de:', 'Tasa Nominal de Inter�s e Inflaci�n'});
legend('tasa de inter�s nominal','inflaci�n','Banda 95% Inf','Location','northeast');
xlim([1 20]);

toc;

%{
xlim([1954.75 2017]);
ylim([-5 20])
%}
