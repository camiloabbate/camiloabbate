%modifiquemos A y G, nada mas)
%donde dice A en realidad van a ir los componentes de F: bii y cia , 
%la G meter exactamente como H'

function [x_hat,loglik] = mkalman_filter( Fm, G, Q, R, Y, x0, Sigma0 )

%A de antes es (b1,b2,b3,b4...
% function [ x_hat, loglik ] = kalman_filter( A, G, Q, R, Y, x0, Sigma0 )
% 
% KALMAN_FILTER computes the Kalman filter and log-likelihood of the time
% invariant linear model in state space form:
%
%       x[t+1] = A x[t] + w[t+1]
%       y[t]   = G x[t] + v[t]
%
%       E[ w(t+1) w(t+1)' ] = Q
%       E[ v(t) v(t)' ]     = R
%       E[ w(t+1) w(s)' ]   = 0 for s ~= t+1 
%       E[ v(t) v(s)' ]     = 0 for s ~= t
%       E[ w(t+1) v(s)' ]   = 0 for all t,s.
% 
% where x[t] is the mx1 vector of states, y[t] is the px1 vector of
% observables, A is mxm, G is pxm, Q is mxm and R is pxp.
%
% INPUTS:
% 1) Matrices of state-space representation: A, G, Q, R.
% 2) Y  : Time series of the observables ( of dimension p x T )
% 3) x0 : Initial value of the state (typically, the unconditinoal mean)
% 4) Sigma0 : Initial Covariance matrix of the state (Optional Argument)
%
% OUTPUT:
% x_hat : Linear projection of x(t) on x(t-1), y(t), y(t-1),..., y(0)
% loglik: Loglikelihood of the model: sum_t log Prob(y_t)
%
% References:
% (1) Hamilton (1994) 'Time Series Analysis'
%
% Written By Constantino Hevia. November 2007.
% Modified March 4, 2008
% Modified August 10, 2011:
%   i. Do not use trace to compute log-likelihood)
%  ii. Add term p*log(2*pi) to likelihood value
% iii. Update covariance matrix in one step instead of two
% Modified October 2012:
%   i. Use reshape function to compute S0

%vamos poniendo por orden, OJO CON EL INPUT Fm
b1=Fm(1,1);
b2=Fm(1,2);
b3=Fm(1,3);
b4=Fm(1,4);
b5=Fm(1,5);
b6=Fm(1,6);
b7=Fm(1,7);
b8=Fm(1,8);
b9=Fm(1,9);
b10=Fm(1,10);
b11=Fm(1,11);
b12=Fm(1,12);
c11=Fm(1,13);
c12=Fm(1,14);
c13=Fm(1,15);
c14=Fm(1,16);
c21=Fm(1,17);
c22=Fm(1,18);
c23=Fm(1,19);
c24=Fm(1,20);
c31=Fm(1,21);
c32=Fm(1,22);
c33=Fm(1,23);
c34=Fm(1,24);
r1=Fm(1,25);
r2=Fm(1,26);
r3=Fm(1,27);
r4=Fm(1,28);


B1=[b1 0 0; 0 b2 0; 0 0 b3];

B2=[b4 0 0; 0 b5 0; 0 0 b6];

B3=[b7 0 0; 0 b8 0; 0 0 b9];

B4 = [b10 0 0; 0 b11 0; 0 0 b12];

Ce= [c11 c12 c13 c14;c21 c22 c23 c24; c31 c32 c33 c34];

rro=[r1 0 0 0; 0 r2 0 0 ; 0 0 r3 0; 0 0 0 r4];

Ident=eye(9);
Cero1=zeros(9,3);
Cero2=zeros(9,4);
Cero3=zeros(4,12);

CP=Ce*rro;

A=[B1 B2 B3 B4 CP ;[Ident Cero1] Cero2; Cero3 rro];


%para nosotros G ser�a tal que G=[1 0 0 -1 0 0 0 0 0 0 0 0 0 0 1 0 ; 0 -1 1 0 0 0 0 0 0 0 0 0 0 0 0 0;0 0 1 0 0 -1 0 0 0 0 0 0 1 0 0 0];

% Compute dimensions
m=size(A,1);  % Number of states para este caso nada m�s
[p, T] = size(Y);        % p= number of observables, T=number of periods
 
%%%ojo ac�:
if nargin<7     % Initialize Sigma0 to the unconditional covariance of x
    S0 = ( eye(m^2)-kron(A,A) ) \ Q(:);     % Vectorized Covariance
    Sigma0 = reshape(S0,m,m);               % Initial covariance matrix
end

x_hat = zeros(m,T+1);   % Initialize array for linear projections
x_hat(:,1) = x0;        % Initialize state
Sigma = Sigma0;         % Initialize covariance of x-x_hat
loglik = 0;             % Initialize log-likelihood 


%ac� arranca el kilombo de par�metros a poner



for t=1:T   % Kalman Recursion
    Omega = G*Sigma*G'+R;                               % Covariance of y(t)-E(y(t)|x_hat(t),Y(t-1))
    K     = A*Sigma*G'/Omega;                           % Kalman Gain
    Sigma = (A-K*G)*Sigma*(A-K*G)' + Q + K*R*K';        % Update Covariance
    at = Y(:,t)-G*x_hat(:,t);                           % Innovation in Y(:,t)
    x_hat(:,t+1) = A*x_hat(:,t) + K * at;               % Projection of x(t+1)
    loglik = loglik + log(det(Omega)) + at'*(Omega\at); % Update log-likelihood
end
loglik = -0.5*( loglik + T*p*log(2*pi) ); % Log-likelihood value