function [ loglik, param_out, unobserved ] = fmin_fisher( param_in, data )

T = length(data);

option_fmu = optimset('Largescale','off','Display','iter','MaxFunEvals',16000,...
                       'Maxiter',5000,'TolX',1e-12,'Tolfun',1e-8);

fprintf('\n Optimizing using Nelder-Mead simplex (direct search) method: fminunc \n')
[ param_out, loglik ] = fminsearch( @log_likelihood, param_in, option_fmu );
        
loglik = -loglik;   % Put it back in right units

fprintf('Done. \n ')

% NESTED FUNCTION: Likelihood function.
    function loglik = log_likelihood( param )
        
       % Parameters:
        media1  = param(1);
        media2 = param(2);
        media3  = param(3);
        b1  = param(4);
        b2 = param(5);
        b3  = param(6);
        b4 = param(7);
        b5  = param(8);
        b6 = param(9);
        b7  = param(10);
        b8 = param(11);
        b9  = param(12);
        b10 = param(13);
        b11  = param(14);
        b12 = param(15);
        c11  = param(16);
        c12 = param(17);
        c13 = param(18);
        c14 = param(19) ;
        c21 = param(20);
        c22 = param(21);
        c23 = param(22);
        c24 = param(23);
        c31 = param(24);
        c32 = param(25);
        c33 = param(26);
        c34 = param(27);
        r1 = param(28);
        r2 = param(29);
        r3 = param(30);
        r4 = param(31);
        phi1= param(32);
        phi2 = param(33);
        phi3 = param(34);
        phi4 = param(35);
        RR1 = param(36);
        RR2 = param(37);
        RR3 = param(38);
        
       RR1_b = exp(RR1);
       RR2_b = exp(RR2);
       RR3_b = exp(RR3);
       
              
        Hprima=[1 0 0 -1 0 0 0 0 0 0 0 0 0 0 1 0 ; 0 -1 1 0 0 0 0 0 0 0 0 0 0 0 0 0;0 0 1 0 0 -1 0 0 0 0 0 0 1 0 0 0];
        G=Hprima;
        R=[RR1_b 0 0; 0 RR2_b 0; 0 0 RR3_b];
        Phi=[phi1 0 0 0; 0 phi2 0 0; 0 0 phi3 0; 0 0 0 phi4];
        Cee=[c11 c12 c13 c14; c21 c22 c23 c24; c31 c32 c33 c34];
        P=[Cee*Phi;zeros(9,4);Phi];
        Q=P*P';
        Fm=[b1 b2 b3 b4 b5 b6 b7 b8 b9 b10 b11 b12 c11 c12 c13 c14 c21 c22 c23 c24 c31 c32 c33 c34 r1 r2 r3 r4];
        % Transform data
        
       primer=data(:,1)';
       segun=data(:,2)';
       tercer=data(:,3)';
       
       pri=ones(size(primer))*media1;
       seg=ones(size(segun))*media2;
       ter=ones(size(segun))*media3;
       
       mu=[pri;seg;ter];
       
       
       Y =data' - mu ;      % Demeaned ex-post real rates (time series in rows)
        
        [unobserved, loglik ] = mkalman_filter(Fm, G , Q, R, Y, 0 );
        
        loglik = -loglik;   % Because we are minimizing
        
    end

end