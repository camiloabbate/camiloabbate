clear all;
clc;

%Para generarme las Impulse Response primero defino la cantidad de:
%variables, shocks y "periodos para las respuestas"

periodos_irf=100;
vars=16;
shocks=4;

%%%%%                 Estrategia:              %%%%%%%%%%%%%%
%Armar el state space system de Uribe: con las matrices F,P,H',A'
%Y luego simular shocks sobre la ecuaci�n state, para luego multiplicar
%por H' y tener el efecto sobre los Observables:
%Detalle no menor: La matriz de observables contiene un par de elementos
%en diferencias, por lo que habr�a que sumar los IRFS para tener el efecto
%en niveles!

%Defino todas las matrices que conforman la ecuaci�n State:
% Eps(t+1) = F*Eps(t) + P*shocks(t+1) 


B1=eye(3)*0.95;
B2=zeros(3);
B3=B2;
B4=B2;
rho=vertcat(horzcat(eye(3)*0.3,zeros(3,1)),horzcat(zeros(1,3),0.7));
Ident=eye(9);
Cero1=zeros(9,3);
Cero2=zeros(9,4);
Cero3=zeros(4,12);
c12=-1;
c21=-1;
c22=-1;
c31=0;  %�sta es la gamma "problem�tica"
%Paper: normalizaci�n: c32 = c14 = 1
c32=1;
c14=1;
C=[0 c12 0 c14; c21 c22 0 0; c31 c32 0 0];

F=[B1 B2 B3 B4 C*rho;[Ident Cero1] Cero2; Cero3 rho];

%Para armar P solo me falta la matriz Psi:
psi=eye(4);

P=[C*psi;Cero2;psi];


%Loop para las IRFS
% Initialize arrays to compute impulse responses
irf = zeros(periodos_irf,vars,shocks);  % First dimension:  periods
                                    % Second dimension: variables
                                    % Third dimension: shocks

Fpow=eye(16);   % Initialize matrix Bc^(t-1);

for t=1:periodos_irf
    % Compute all impulse responses at t at once and store result in Yimpt 
    % Yimpt(1:nvar,i) contains irf at t to shock i
    Yimpt = Fpow*P;
    
    % Update Bpowtm1 matrix for next iteration
    Fpow = Fpow*F;
    
    % Store impulse responses at t where they belong
    for ishock=1:shocks     % Iterate over shocks
        irf(t,:,ishock) = Yimpt(1:vars,ishock)';
    end
end


%Hasta ah� me consegu� efectos sobre los No-Observables, por lo que
%necesito multiplicar por la matriz H' para tener el efecto sobre 
%el vector ot
%Llamo HH a la matriz H' de Uribe:

HH=[1 0 0 -1 0 0 0 0 0 0 0 0 0 0 1 0 ; 0 -1 1 0 0 0 0 0 0 0 0 0 0 0 0 0;0 0 1 0 0 -1 0 0 0 0 0 0 1 0 0 0];

%Aclaraci�n: Las siguientes matrices "Primer,.....,Cuart" son matrices de 
% 3x100, que almacenan las respuestas de los observables frente a:
%Primer shock: permanente, monetario  (xm)
%Segundo shock: no-permanente, monetario  (zm)
%Tercer shock: permanente, no monetario   (xn)
%Cuarto shock: no permanente, no monetario   (zn)

Primer=HH*irf(:,:,1)';
Segun=HH*irf(:,:,2)';
Tercer=HH*irf(:,:,3)';
Cuart=HH*irf(:,:,4)';

%Hasta ac� tengo las impulse response sobre:
% [ variaci�n output 
%   tasa de inter�s real
%   variaci�n tasa de i nominal ]


%Entonces para hallar los impulse response sobre los niveles del output
%y los niveles de la tasa de i nominal tengo que sumar los irfs


%ahora efecto sobre nivel de it
%esto nos va a servir para despu�s hallar efecto sobre pit
% pit = it - rt

for i=1:periodos_irf;
    B=Primer(3,1:i);
    inominal_shock1(i)=sum(B);  %efecto sobre i nominal shock xm
end

ireal_shock1=Primer(2,:);



%Shock xm, monetario permanente sobre nivel de output
for i=1:periodos_irf;
    Z=Primer(1,1:i);
    output_shock1(i)=sum(Z);
end


%Ahora, shocks transitorios

ireal_shock2=Segun(2,:);


%computo efecto de shock transitorio monetario sobre nivel de output
for i=1:periodos_irf;
    K=Segun(1,1:i);
    output_shock2(i)=sum(K);
end

%computo efecto de shock transitorio monetario sobre nivel de tasa de i
%nominal
for i=1:periodos_irf;
    L=Segun(3,1:i);
    inominal_shock2(i)=sum(L);
end


%�sto ya no me sirve
%{ 
figure(2);
subplot(2,2,1)
plot(1:periodos_irf,output_shock2);
title('Respuesta de output frente a shock monetario transitorio');



%}

%y por ultimo shock transitorio no-monetario 
%solo le pega al output


for i=1:periodos_irf;
    U=Cuart(1,1:i);
    output_shock4(i)=sum(U);
end

%{ 
figure(2);
plot(1:periodos_irf,output_shock4);
title({'Shock Transitorio sobre la TFP','Respuesta del Output',});
%}

figure(1);
subplot(2,2,1);
hold on;
plot(1:periodos_irf,inominal_shock1,'--r','LineWidth',2);
plot(1:periodos_irf,inominal_shock1-ireal_shock1,'-b','LineWidth',2);
title({'Shock Permanente:Tasa Nominal de Inter�s','Respuesta de:', 'Tasa Nominal de Inter�s e Inflaci�n'});
legend('tasa de inter�s nominal','inflaci�n','Location','southeast');

subplot(2,2,2);
hold on;
plot(1:periodos_irf,inominal_shock2,'--r','LineWidth',2);
plot(1:periodos_irf,inominal_shock2-ireal_shock2,'-b','LineWidth',2);
title({'Shock Transitorio:Tasa Nominal de Inter�s','Respuesta de:', 'Tasa Nominal de Inter�s e Inflaci�n'});
legend('tasa de inter�s nominal','inflaci�n','Location','southeast');

subplot(2,2,3);
hold on;
plot(1:periodos_irf,ireal_shock2,'-g','LineWidth',2);
title({'Shock Transitorio:Tasa Nominal de Inter�s','Respuesta de la Tasa de Inter�s Real'});
legend('Tasa de I. Real','Location','northeast');

subplot(2,2,4);
hold on;
plot(1:periodos_irf,output_shock2,'-b','LineWidth',2);
title({'Shock Transitorio:Tasa Nominal de Inter�s','Respuesta del Output'});
legend('Output','Location','northeast');

saveas(gca, 'Impulse.eps','epsc');



