Data scrapped from the website: whoscored.com
For the purpose of this readme, I'll use the English Premier League of season 2009/2010 as an example:

https://www.whoscored.com/Regions/252/Tournaments/2/Seasons/1849/Stages/3115/RefereeStatistics/England-Premier-League-2009-2010

As one can see in the previous link, there are 4 tabs with relevant data:
Under the big tab "Discipline" we can find the tabs "Overall" , "Home" and "Away"
The last one is in "Results"

In this folder, called "ref_data", we can actually find 5 subfolders.
The 5th one is called "complete", that hosts a merge of the data in "Overall" , "Home" and "Away"
The purpose of this merged dataset is dual:
First, it's very useful to have all that information in just one file.
Second, it serves as a sanity check: For example, if in 2009/2010, the referee Howard Webb gave
43 yellow cards to home teams and 53 yellow cards to away teams, then he gave a total of 43+53 = 96  yellow cards
(And that should be consistent with what we observe in "Overall")

As a matter of fact, I created a column called "consistent" in the datasets hosted in the subflder "complete",
that originally contained some observations with the value of "no". What happened was that the website had some
typos (or at least everything indicated that) so for some referees, the combination of overall, away and home did not
coincide. I proceeded to manually clean and conciliate those discrepancies. In case it's of interest, the referees and
years that I had to clean were:

Brazil:
# M. deL. Henrique 2020
# R.D. Ferreira 2020

France:
# Sébastien Desiage  2018 2017/2018
# Amaury Delerue     2019 2018/2019
# Nicolas Rainville  2019 2018/2019
# Hakim Ben El Hadj  2020 2019/2020
# Amaury Delerue     2020 2019/2020
# Benoît Bastien     2020 2019/2020

Netherlands:
# Björn Kuipers       2019 2018/2019
# Edwin van de Graaf  2020 2019/2020


As a final note, there was a referee that was duplicated in Brazil:
https://www.whoscored.com/Regions/31/Tournaments/95/Seasons/3753/Stages/7479/RefereeStatistics/Brazil-Brasileir%C3%A3o-2013
E.E. da Silva, in year 2013, shows up twice in all the tabs. In one row, the variable appereances equal 4.
In another row, the variable appereances equal 2. I believe this was manually inputed in the website and they forgot
to erase the row with the variable appeareances equal to 2. I erased that observation.